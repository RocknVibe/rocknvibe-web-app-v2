# RocknVibe V2 - Cloudflare Deployment Guide

This guide explains how to deploy RocknVibe V2 on Cloudflare Pages and Workers.

## Prerequisites

- A Cloudflare account
- `wrangler` CLI installed (`npm install -g wrangler`)
- Git repository connected to your Cloudflare account

## Deployment Options

### Option 1: Cloudflare Pages (Recommended for Frontend)

Cloudflare Pages is ideal for hosting the React frontend with automatic builds and deployments.

#### Setup Steps:

1. **Connect your GitHub repository**
   - Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
   - Navigate to **Pages**
   - Click **Create a project** → **Connect to Git**
   - Select your GitHub account and `rocknvibe-web-app-v2` repository

2. **Configure build settings**
   - **Framework preset**: Vite
   - **Build command**: `pnpm run build`
   - **Build output directory**: `dist/public`
   - **Root directory**: `.` (or leave blank)

3. **Set environment variables**
   - In the Cloudflare Pages project settings, add:
     ```
     VITE_API_URL=https://api.rocknvibe.com
     ```

4. **Deploy**
   - Push to your main branch, and Cloudflare will automatically build and deploy

### Option 2: Cloudflare Workers (For Backend API)

Cloudflare Workers can host your Express backend or act as an API gateway.

#### Setup Steps:

1. **Authenticate with Cloudflare**
   ```bash
   wrangler login
   ```

2. **Update `wrangler.toml`**
   - Set your `account_id` from Cloudflare Dashboard
   - Update route patterns for your domain
   - Configure KV namespaces, D1 database, and R2 buckets as needed

3. **Deploy the Worker**
   ```bash
   wrangler deploy
   ```

### Option 3: Full Stack on Cloudflare (Pages + Workers)

For a complete setup:

1. **Deploy frontend to Pages** (as described above)
2. **Deploy backend to Workers** (as described above)
3. **Configure API routes** in `_redirects` to point to your Workers API

## Configuration Files

### `wrangler.toml`
- Configures Cloudflare Workers deployment
- Defines KV namespaces, D1 databases, R2 buckets
- Sets up environment-specific configurations

### `_redirects`
- Handles URL routing for Cloudflare Pages
- Redirects API calls to your backend
- Implements SPA fallback routing

### `_headers`
- Sets security and performance headers
- Configures caching policies
- Enables CORS headers

## Environment Variables

Create a `.env.production` file for production deployments:

```env
VITE_API_URL=https://api.rocknvibe.com
NODE_ENV=production
DATABASE_URL=your_production_db_url
```

For Cloudflare Pages, add these via the dashboard:
- **Settings** → **Environment variables** → **Production**

## Database Setup (D1)

If using Cloudflare D1 for your database:

1. **Create a D1 database**
   ```bash
   wrangler d1 create rocknvibe-db
   ```

2. **Update `wrangler.toml`** with the database ID

3. **Run migrations**
   ```bash
   wrangler d1 execute rocknvibe-db --file=drizzle/0000_medical_network.sql
   ```

## KV Namespace Setup

For caching and session storage:

1. **Create KV namespaces**
   ```bash
   wrangler kv:namespace create CACHE
   wrangler kv:namespace create SESSIONS
   ```

2. **Update `wrangler.toml`** with the namespace IDs

## R2 Bucket Setup

For file storage:

1. **Create an R2 bucket**
   ```bash
   wrangler r2 bucket create rocknvibe-assets
   ```

2. **Update `wrangler.toml`** with the bucket name

## Monitoring & Analytics

Cloudflare provides built-in analytics:

- **Pages Analytics**: View traffic, build status, and performance metrics
- **Workers Analytics**: Monitor request counts, errors, and latency
- **Real User Monitoring (RUM)**: Track actual user experience

Enable in the Cloudflare dashboard under **Analytics & Logs**.

## Custom Domain

1. Go to your Cloudflare Pages project
2. **Settings** → **Custom domain**
3. Add your domain (e.g., `rocknvibe.com`)
4. Update DNS records as instructed

## SSL/TLS Certificate

Cloudflare automatically provides free SSL/TLS certificates:
- **Flexible**: Cloudflare to origin (not recommended for production)
- **Full**: Cloudflare to origin with certificate
- **Full (Strict)**: Cloudflare to origin with valid certificate (recommended)

Set in **SSL/TLS** → **Overview** → **Encryption mode**

## Performance Optimization

### Caching Strategy
- **Static assets**: 1 year cache
- **Images**: 1 day cache
- **API routes**: No cache (must-revalidate)

### Edge Functions
Use Cloudflare's edge functions for:
- Request authentication
- Custom routing logic
- Rate limiting
- Request/response transformation

## Troubleshooting

### Build Failures
- Check build logs in Cloudflare Pages dashboard
- Verify `package.json` scripts are correct
- Ensure all environment variables are set

### API Connection Issues
- Verify `_redirects` configuration
- Check CORS headers in `_headers`
- Test API endpoint directly

### Database Connection Issues
- Verify D1 database is created and bound
- Check connection string in environment variables
- Review database migration logs

## Deployment Checklist

- [ ] GitHub repository connected to Cloudflare
- [ ] Build command configured correctly
- [ ] Environment variables set in Cloudflare dashboard
- [ ] Custom domain configured
- [ ] SSL/TLS certificate enabled
- [ ] Database (D1) created and migrations run
- [ ] KV namespaces created and bound
- [ ] R2 bucket created (if needed)
- [ ] Monitoring and analytics enabled
- [ ] Test deployment in staging environment first

## Support

For more information:
- [Cloudflare Pages Documentation](https://developers.cloudflare.com/pages/)
- [Cloudflare Workers Documentation](https://developers.cloudflare.com/workers/)
- [Cloudflare D1 Documentation](https://developers.cloudflare.com/d1/)
