/**
 * RocknVibe V2 - Cloudflare Worker Entry Point
 * This file serves as the main entry point for the Cloudflare Worker
 * It handles API requests and routes them to the appropriate handlers
 */

import { Router } from 'itty-router';

// Create a new router
const router = Router();

/**
 * Health check endpoint
 */
router.get('/health', () => {
  return new Response(
    JSON.stringify({
      status: 'ok',
      worker: 'misty-pond-3706',
      timestamp: new Date().toISOString(),
    }),
    {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    }
  );
});

/**
 * API routes
 */
router.post('/api/auth/login', async (request) => {
  try {
    const body = await request.json();
    // Handle login logic here
    return new Response(
      JSON.stringify({ success: true, message: 'Login successful' }),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Invalid request' }),
      {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      }
    );
  }
});

router.get('/api/content', async (request) => {
  // Handle content retrieval from KV or database
  return new Response(
    JSON.stringify({ data: [] }),
    {
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    }
  );
});

/**
 * CORS preflight handling
 */
router.options('*', () => {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
});

/**
 * 404 handler
 */
router.all('*', () => {
  return new Response(
    JSON.stringify({ error: 'Not Found' }),
    {
      status: 404,
      headers: { 'Content-Type': 'application/json' },
    }
  );
});

/**
 * Export the handler for Cloudflare Workers
 */
export default {
  fetch: router.handle,
};
