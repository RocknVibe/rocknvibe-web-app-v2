/**
 * Backend Utilities
 * Provides common utilities for error handling, logging, and response formatting
 */

import { TRPCError } from "@trpc/server";

/**
 * Custom error codes for the application
 */
export const ErrorCodes = {
  INVALID_INPUT: "INVALID_INPUT",
  NOT_FOUND: "NOT_FOUND",
  UNAUTHORIZED: "UNAUTHORIZED",
  FORBIDDEN: "FORBIDDEN",
  CONFLICT: "CONFLICT",
  INTERNAL_ERROR: "INTERNAL_ERROR",
  SERVICE_UNAVAILABLE: "SERVICE_UNAVAILABLE",
} as const;

/**
 * Create a standardized TRPC error
 */
export function createTRPCError(
  code: keyof typeof ErrorCodes,
  message: string,
  cause?: unknown
): TRPCError {
  return new TRPCError({
    code: code as any,
    message,
    cause,
  });
}

/**
 * Safe error handler that logs and returns appropriate error
 */
export function handleError(error: unknown, defaultMessage: string = "An error occurred"): TRPCError {
  if (error instanceof TRPCError) {
    return error;
  }

  if (error instanceof Error) {
    console.error("[Backend Error]", error.message, error.stack);
    return createTRPCError("INTERNAL_ERROR", defaultMessage, error);
  }

  console.error("[Backend Error]", error);
  return createTRPCError("INTERNAL_ERROR", defaultMessage, error);
}

/**
 * Validate required fields
 */
export function validateRequired(
  data: Record<string, any>,
  requiredFields: string[]
): { valid: boolean; error?: string } {
  for (const field of requiredFields) {
    if (!data[field]) {
      return {
        valid: false,
        error: `Missing required field: ${field}`,
      };
    }
  }
  return { valid: true };
}

/**
 * Rate limiting helper
 */
export class RateLimiter {
  private attempts: Map<string, { count: number; resetTime: number }> = new Map();

  constructor(private maxAttempts: number = 10, private windowMs: number = 60000) {}

  isAllowed(key: string): boolean {
    const now = Date.now();
    const record = this.attempts.get(key);

    if (!record || now > record.resetTime) {
      this.attempts.set(key, { count: 1, resetTime: now + this.windowMs });
      return true;
    }

    if (record.count < this.maxAttempts) {
      record.count++;
      return true;
    }

    return false;
  }

  reset(key: string): void {
    this.attempts.delete(key);
  }

  cleanup(): void {
    const now = Date.now();
    for (const [key, record] of this.attempts.entries()) {
      if (now > record.resetTime) {
        this.attempts.delete(key);
      }
    }
  }
}

/**
 * Pagination helper
 */
export interface PaginationParams {
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

export function getPaginationParams(
  page?: number,
  limit?: number,
  maxLimit: number = 100
): { skip: number; take: number; page: number; limit: number } {
  const p = Math.max(1, page || 1);
  const l = Math.min(Math.max(1, limit || 10), maxLimit);
  return {
    skip: (p - 1) * l,
    take: l,
    page: p,
    limit: l,
  };
}

export function createPaginatedResponse<T>(
  data: T[],
  total: number,
  page: number,
  limit: number
): PaginatedResponse<T> {
  return {
    data,
    total,
    page,
    limit,
    pages: Math.ceil(total / limit),
  };
}

/**
 * Cache helper for simple in-memory caching
 */
export class SimpleCache<T> {
  private cache: Map<string, { value: T; expiresAt: number }> = new Map();

  constructor(private defaultTtlMs: number = 60000) {}

  set(key: string, value: T, ttlMs?: number): void {
    const expiresAt = Date.now() + (ttlMs || this.defaultTtlMs);
    this.cache.set(key, { value, expiresAt });
  }

  get(key: string): T | null {
    const item = this.cache.get(key);
    if (!item) return null;

    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return item.value;
  }

  delete(key: string): void {
    this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
  }

  cleanup(): void {
    const now = Date.now();
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiresAt) {
        this.cache.delete(key);
      }
    }
  }
}

/**
 * Response formatter for consistent API responses
 */
export function formatSuccessResponse<T>(data: T, message?: string) {
  return {
    success: true,
    data,
    message: message || "Operation completed successfully",
  };
}

export function formatErrorResponse(error: string, code?: string) {
  return {
    success: false,
    error,
    code: code || "ERROR",
  };
}

/**
 * Async wrapper to catch errors in route handlers
 */
export function asyncHandler(fn: Function) {
  return async (...args: any[]) => {
    try {
      return await fn(...args);
    } catch (error) {
      throw handleError(error);
    }
  };
}
