/**
 * Backend Middleware
 * Provides middleware for request handling, security, and performance
 */

import express, { Request, Response, NextFunction } from "express";
import { RateLimiter } from "./utils";

/**
 * Rate limiter instances for different endpoints
 */
const apiRateLimiter = new RateLimiter(100, 60000); // 100 requests per minute
const authRateLimiter = new RateLimiter(5, 300000); // 5 requests per 5 minutes
const uploadRateLimiter = new RateLimiter(10, 3600000); // 10 requests per hour

/**
 * Middleware to add request ID and timing
 */
export function requestMetadataMiddleware(req: Request, res: Response, next: NextFunction) {
  req.id = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  req.startTime = Date.now();

    res.on("finish", () => {
    const duration = req.startTime ? Date.now() - req.startTime : 0;
    console.log(`[${req.id}] ${req.method} ${req.path} - ${res.statusCode} - ${duration}ms`);
  });

  next();
}

/**
 * Middleware for API rate limiting
 */
export function apiRateLimitMiddleware(req: Request, res: Response, next: NextFunction) {
  const clientId = req.ip || req.socket.remoteAddress || "unknown";

  if (!apiRateLimiter.isAllowed(clientId)) {
    return res.status(429).json({
      error: "Too many requests",
      retryAfter: 60,
    });
  }

  next();
}

/**
 * Middleware for authentication rate limiting
 */
export function authRateLimitMiddleware(req: Request, res: Response, next: NextFunction) {
  const clientId = `${req.ip}_${req.path}` || "unknown";

  if (!authRateLimiter.isAllowed(clientId)) {
    return res.status(429).json({
      error: "Too many authentication attempts",
      retryAfter: 300,
    });
  }

  next();
}

/**
 * Middleware for upload rate limiting
 */
export function uploadRateLimitMiddleware(req: Request, res: Response, next: NextFunction) {
  const clientId = req.ip || req.socket.remoteAddress || "unknown";

  if (!uploadRateLimiter.isAllowed(clientId)) {
    return res.status(429).json({
      error: "Upload limit exceeded",
      retryAfter: 3600,
    });
  }

  next();
}

/**
 * Middleware for security headers
 */
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  // Prevent clickjacking
  res.setHeader("X-Frame-Options", "SAMEORIGIN");

  // Prevent MIME sniffing
  res.setHeader("X-Content-Type-Options", "nosniff");

  // Enable XSS protection
  res.setHeader("X-XSS-Protection", "1; mode=block");

  // Content Security Policy
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;"
  );

  // Referrer Policy
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");

  // Permissions Policy
  res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");

  next();
}

/**
 * Middleware for CORS handling
 */
export function corsMiddleware(req: Request, res: Response, next: NextFunction) {
  const allowedOrigins = [
    "http://localhost:3000",
    "http://localhost:5173",
    process.env.FRONTEND_URL,
  ].filter(Boolean);

  const origin = req.headers.origin;

  if (origin && allowedOrigins.includes(origin as string)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  }

  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Max-Age", "86400");

  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }

  next();
}

/**
 * Middleware for error handling
 */
export function errorHandlingMiddleware(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  console.error(`[${req.id}] Error:`, err);

  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  res.status(statusCode).json({
    error: message,
    code: err.code || "INTERNAL_ERROR",
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  });
}

/**
 * Middleware for request validation
 */
export function validateContentType(
  allowedTypes: string[] = ["application/json"]
) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.method === "GET" || req.method === "DELETE") {
      return next();
    }

    const contentType = req.headers["content-type"]?.split(";")[0];

    if (!contentType || !allowedTypes.includes(contentType)) {
      return res.status(415).json({
        error: "Unsupported Media Type",
        allowed: allowedTypes,
      });
    }

    next();
  };
}

/**
 * Middleware for request logging
 */
export function requestLoggingMiddleware(req: Request, res: Response, next: NextFunction) {
  const originalJson = res.json;

  res.json = function (data: any) {
    console.log(`[${req.id}] Response:`, {
      status: res.statusCode,
      data: typeof data === "object" ? Object.keys(data) : data,
    });

    return originalJson.call(this, data);
  };

  next();
}

/**
 * Middleware for compression (should be used with compression package)
 */
export function compressionMiddleware(req: Request, res: Response, next: NextFunction) {
  // This is a placeholder - use the 'compression' npm package for actual implementation
  // import compression from 'compression';
  // app.use(compression());
  next();
}

/**
 * Cleanup function for rate limiters
 */
export function cleanupRateLimiters() {
  apiRateLimiter.cleanup();
  authRateLimiter.cleanup();
  uploadRateLimiter.cleanup();
}

/**
 * Setup all middleware
 */
export function setupMiddleware(app: express.Application) {
  // Request metadata
  app.use(requestMetadataMiddleware);

  // Security headers
  app.use(securityHeadersMiddleware);

  // CORS
  app.use(corsMiddleware);

  // Content type validation
  app.use(validateContentType());

  // Request logging
  app.use(requestLoggingMiddleware);

  // Rate limiting for API
  app.use("/api/", apiRateLimitMiddleware);

  // Auth rate limiting for specific routes
  app.use("/api/oauth/", authRateLimitMiddleware);

  // Upload rate limiting
  app.use("/api/upload/", uploadRateLimitMiddleware);

  // Cleanup rate limiters periodically
  setInterval(cleanupRateLimiters, 60000); // Every minute
}

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      id?: string;
      startTime?: number;
    }
  }
}
