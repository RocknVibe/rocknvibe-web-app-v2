/**
 * Hero Component - RocknVibe Landing
 * Design: Netflix-Style Glassmorphism
 * - Full-screen hero with background image
 * - Glass-effect form with blur
 * - Gradient overlay with smooth transitions
 * - Enhanced animations and effects
 */

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Hero() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsLoading(true);
      setTimeout(() => {
        toast.success("Welcome to Rock N Vibe! Check your email to get started.");
        setEmail("");
        setIsLoading(false);
      }, 600);
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Live concert atmosphere"
          className="w-full h-full object-cover"
        />
        {/* Glass Gradient Overlay */}
        <div className="absolute inset-0 glass-gradient-overlay" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0D1B2A]/60 via-transparent to-[#0D1B2A]/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 container text-center px-4 pt-20">
        <div className="max-w-3xl mx-auto">
          {/* Main Heading */}
          <h1 
            className="font-display font-extrabold text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white leading-tight mb-6 tracking-tight animate-fade-in"
            style={{
              textShadow: "0 0 30px rgba(255, 45, 45, 0.2), 0 0 60px rgba(255, 45, 45, 0.1)"
            }}
          >
            Unlimited music videos,{" "}
            <span className="text-[#FF2D2D] text-glow-strong">live broadcasts</span>, and more
          </h1>

          {/* Subheading */}
          <p 
            className="text-lg sm:text-xl md:text-2xl text-white/90 mb-4 font-medium animate-fade-in"
            style={{
              animationDelay: "0.2s",
              opacity: 0,
              animation: "fade-in 0.8s ease-out 0.2s forwards"
            }}
          >
            Stream anywhere. Cancel anytime.
          </p>

          {/* CTA Text */}
          <p 
            className="text-base sm:text-lg text-white/80 mb-8 animate-fade-in"
            style={{
              animationDelay: "0.4s",
              opacity: 0,
              animation: "fade-in 0.8s ease-out 0.4s forwards"
            }}
          >
            Ready to watch? Enter your email to create or restart your membership.
          </p>

          {/* Email Form with Glass Effect */}
          <form
            onSubmit={handleSubmit}
            className="flex flex-col sm:flex-row gap-3 max-w-xl mx-auto glass-effect-strong p-2 rounded-2xl animate-scale-in"
            style={{
              animationDelay: "0.6s",
              opacity: 0,
              animation: "scale-in 0.6s ease-out 0.6s forwards"
            }}
          >
            <Input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-14 glass-input bg-transparent border-white/20 text-white placeholder:text-white/50 text-base px-5 focus:border-[#FF2D2D] focus:ring-[#FF2D2D]/30 focus:bg-[#0D1B2A]/40"
              required
              disabled={isLoading}
            />
            <Button
              type="submit"
              size="lg"
              disabled={isLoading}
              className="h-14 bg-gradient-to-r from-[#FF2D2D] to-[#FF2D2D]/80 hover:from-[#FF2D2D] hover:to-[#FF2D2D]/70 text-white font-semibold text-lg px-8 whitespace-nowrap transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-[#FF2D2D]/40 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? "Getting Started..." : "Get Started"}
              <ChevronRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Button>
          </form>
        </div>
      </div>

      {/* Bottom Gradient Fade with Glass Effect */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0D1B2A] via-[#0D1B2A]/50 to-transparent" />

      {/* Floating Accent Elements */}
      <div className="absolute top-1/4 right-10 w-72 h-72 bg-[#FF2D2D]/10 rounded-full blur-3xl animate-float" />
      <div className="absolute bottom-1/4 left-10 w-72 h-72 bg-[#FF2D2D]/5 rounded-full blur-3xl animate-float" style={{ animationDelay: "1s" }} />
    </section>
  );
}
