/**
 * Header Component - RocknVibe Navigation
 * Design: Netflix-Style Glassmorphism
 * - Frosted glass header with blur effect
 * - Logo on left, navigation and CTA on right
 * - Smooth transitions and hover effects
 * - Enhanced with glass effects and animations
 */

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { label: "Music Videos", href: "#music-videos" },
    { label: "Live Broadcasts", href: "#live-broadcasts" },
    { label: "Record Label", href: "#record-label" },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled
          ? "glass-effect-strong shadow-lg"
          : "glass-effect"
      )}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="/" className="flex items-center gap-3 group">
            <img
              src="/images/rocknvibe-entertainment-logo.png"
              alt="Rock N Vibe Entertainment"
              className="h-12 md:h-14 w-auto transition-all duration-300 group-hover:scale-110 group-hover:drop-shadow-lg group-hover:drop-shadow-[0_0_12px_rgba(255,45,45,0.3)]"
            />
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item, index) => (
              <a
                key={item.label}
                href={item.href}
                className="text-white/80 hover:text-white font-medium text-sm tracking-wide transition-all duration-300 relative group"
                style={{
                  animation: `slide-in-left 0.6s ease-out forwards`,
                  animationDelay: `${index * 0.1}s`,
                  opacity: 0,
                }}
              >
                {item.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-[#FF2D2D] to-[#FF2D2D]/50 transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <Button
              variant="ghost"
              className="glass-button text-white hover:text-white"
            >
              Sign In
            </Button>
            <Button className="glass-button-red bg-[#FF2D2D] hover:bg-[#FF2D2D]/90 text-white font-semibold px-6 border-0">
              Get Started
            </Button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden text-white p-2 transition-all duration-300 hover:scale-110"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          "md:hidden absolute top-full left-0 right-0 glass-effect-strong overflow-hidden transition-all duration-300",
          isMobileMenuOpen ? "max-h-96 border-b border-white/10" : "max-h-0"
        )}
      >
        <nav className="container py-4 flex flex-col gap-4">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="text-white/80 hover:text-white font-medium py-2 transition-all duration-300 hover:translate-x-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {item.label}
            </a>
          ))}
          <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
            <Button
              variant="ghost"
              className="glass-button text-white hover:text-white justify-start"
            >
              Sign In
            </Button>
            <Button className="glass-button-red bg-[#FF2D2D] hover:bg-[#FF2D2D]/90 text-white font-semibold border-0">
              Get Started
            </Button>
          </div>
        </nav>
      </div>
    </header>
  );
}
