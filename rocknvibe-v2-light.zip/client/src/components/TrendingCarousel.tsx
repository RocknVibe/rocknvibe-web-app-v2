/**
 * Trending Carousel Component
 * Design: Premium Streaming Elegance
 * - Horizontal scrolling carousel with numbered items
 * - Hover effects with scale and shadow
 * - Smooth scroll behavior
 */

import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight, Play } from "lucide-react";
import { useRef, useState } from "react";

interface TrendingItem {
  id: number;
  title: string;
  artist: string;
  image: string;
  rank: number;
}

const trendingItems: TrendingItem[] = [
  {
    id: 1,
    title: "Electric Dreams",
    artist: "Nova Pulse",
    image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=600&fit=crop",
    rank: 1,
  },
  {
    id: 2,
    title: "Midnight Sessions",
    artist: "The Vibers",
    image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&h=600&fit=crop",
    rank: 2,
  },
  {
    id: 3,
    title: "Soul Revolution",
    artist: "Marcus Cole",
    image: "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=400&h=600&fit=crop",
    rank: 3,
  },
  {
    id: 4,
    title: "Urban Beats",
    artist: "DJ Spectrum",
    image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400&h=600&fit=crop",
    rank: 4,
  },
  {
    id: 5,
    title: "Acoustic Journey",
    artist: "Luna Ray",
    image: "https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=400&h=600&fit=crop",
    rank: 5,
  },
  {
    id: 6,
    title: "Neon Nights",
    artist: "Synth Wave",
    image: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400&h=600&fit=crop",
    rank: 6,
  },
  {
    id: 7,
    title: "Bass Drop",
    artist: "Heavy Groove",
    image: "https://images.unsplash.com/photo-1501612780327-45045538702b?w=400&h=600&fit=crop",
    rank: 7,
  },
];

export default function TrendingCarousel() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <section className="py-12 bg-[#0D1B2A]" id="music-videos">
      <div className="container">
        {/* Section Header */}
        <h2 className="font-display font-bold text-2xl md:text-3xl text-white mb-6">
          Trending Now
        </h2>

        {/* Carousel Container */}
        <div className="relative group">
          {/* Left Arrow */}
          <button
            onClick={() => scroll("left")}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full bg-gradient-to-r from-[#0D1B2A] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-start"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-8 h-8 text-white" />
          </button>

          {/* Scrollable Content */}
          <div
            ref={scrollRef}
            className="flex gap-2 overflow-x-auto scrollbar-hide scroll-smooth pb-4"
          >
            {trendingItems.map((item) => (
              <div
                key={item.id}
                className="relative flex-shrink-0 group/card cursor-pointer"
                onMouseEnter={() => setHoveredId(item.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                {/* Rank Number */}
                <div className="absolute -left-2 bottom-0 z-10">
                  <span
                    className="font-display font-black text-8xl md:text-9xl text-transparent"
                    style={{
                      WebkitTextStroke: "2px rgba(255,255,255,0.3)",
                    }}
                  >
                    {item.rank}
                  </span>
                </div>

                {/* Card */}
                <div
                  className={cn(
                    "relative w-32 md:w-40 h-48 md:h-56 rounded-md overflow-hidden ml-8 transition-all duration-300",
                    hoveredId === item.id && "scale-110 shadow-2xl z-20"
                  )}
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Hover Overlay */}
                  <div
                    className={cn(
                      "absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-3 transition-opacity duration-300",
                      hoveredId === item.id ? "opacity-100" : "opacity-0"
                    )}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center">
                        <Play className="w-4 h-4 text-black fill-black ml-0.5" />
                      </div>
                    </div>
                    <p className="text-white font-semibold text-sm truncate">
                      {item.title}
                    </p>
                    <p className="text-white/70 text-xs truncate">
                      {item.artist}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right Arrow */}
          <button
            onClick={() => scroll("right")}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-full bg-gradient-to-l from-[#0D1B2A] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-end"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-8 h-8 text-white" />
          </button>
        </div>
      </div>
    </section>
  );
}
