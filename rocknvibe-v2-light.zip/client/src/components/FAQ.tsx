/**
 * FAQ Component
 * Design: Premium Streaming Elegance
 * - Accordion-style FAQ items
 * - Smooth expand/collapse animations
 * - Clean, minimal design
 */

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronRight } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const faqItems = [
  {
    id: "1",
    question: "What is Rock N Vibe Entertainment?",
    answer:
      "Rock N Vibe Entertainment is a streaming platform dedicated to music videos, live broadcasts, and exclusive content from our record label artists. We showcase diverse talent across multiple genres, bringing you live performances and behind-the-scenes access to the music industry through The Vibe TV.",
  },
  {
    id: "2",
    question: "How much does The Vibe TV cost?",
    answer:
      "The Vibe TV offers flexible plans starting at $4.99/month for our ad-supported tier. Our premium plan at $9.99/month gives you ad-free viewing, offline downloads, and early access to live broadcasts. We also offer annual plans with significant savings.",
  },
  {
    id: "3",
    question: "Where can I watch?",
    answer:
      "Watch anywhere, anytime. Sign in with your Rock N Vibe account to watch on your computer at rocknvibe.com, or on any internet-connected device that offers The Vibe TV app, including smart TVs, smartphones, tablets, streaming media players, and game consoles.",
  },
  {
    id: "4",
    question: "How do I cancel?",
    answer:
      "Rock N Vibe Entertainment is flexible. There are no annoying contracts and no commitments. You can easily cancel your account online in two clicks. There are no cancellation fees – start or stop your account anytime.",
  },
  {
    id: "5",
    question: "What can I watch on The Vibe TV?",
    answer:
      "The Vibe TV has an extensive library of music videos, live concert recordings, behind-the-scenes documentaries, artist interviews, and exclusive live broadcasts. We feature content across all genres including rock, pop, hip-hop, electronic, jazz, and more.",
  },
  {
    id: "6",
    question: "How do I join the record label?",
    answer:
      "Rock N Vibe Entertainment is always looking for fresh talent. If you're an artist interested in joining our label, visit our Artists section and submit your demo. Our A&R team reviews all submissions and will reach out if there's a potential fit.",
  },
];

export default function FAQ() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success("Welcome to Rock N Vibe! Check your email to get started.");
      setEmail("");
    }
  };

  return (
    <section className="py-16 bg-[#0D1B2A]" id="record-label">
      <div className="container max-w-4xl">
        {/* Section Header */}
        <h2 className="font-display font-bold text-2xl md:text-3xl text-white mb-8 text-center">
          Frequently Asked Questions
        </h2>

        {/* Accordion */}
        <Accordion type="single" collapsible className="space-y-2">
          {faqItems.map((item) => (
            <AccordionItem
              key={item.id}
              value={item.id}
              className="border-none bg-[#1A2B3D] rounded-lg overflow-hidden"
            >
              <AccordionTrigger className="px-6 py-5 text-white hover:no-underline hover:bg-[#243447] transition-colors text-left font-medium text-base md:text-lg [&[data-state=open]>svg]:rotate-45 [&>svg]:text-white [&>svg]:h-6 [&>svg]:w-6">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-5 text-white/80 text-base leading-relaxed border-t border-white/10">
                <div className="pt-4">{item.answer}</div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        {/* CTA Section */}
        <div className="mt-12 text-center">
          <p className="text-white/80 text-base md:text-lg mb-6">
            Ready to watch? Enter your email to create or restart your
            membership.
          </p>
          <form
            onSubmit={handleSubmit}
            className="flex flex-col sm:flex-row gap-3 max-w-xl mx-auto"
          >
            <Input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-14 bg-[#1A2B3D] border-white/20 text-white placeholder:text-white/50 text-base px-5 focus:border-[#FF2D2D] focus:ring-[#FF2D2D]/30"
              required
            />
            <Button
              type="submit"
              size="lg"
              className="h-14 bg-[#FF2D2D] hover:bg-[#FF2D2D]/90 text-white font-semibold text-lg px-8 whitespace-nowrap transition-all duration-300 hover:scale-105"
            >
              Get Started
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}
