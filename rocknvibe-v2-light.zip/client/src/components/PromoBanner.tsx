/**
 * Promo Banner Component
 * Design: Premium Streaming Elegance
 * - Horizontal banner with The Vibe TV logo, text, and CTA
 * - Subtle gradient background
 * - Hover effects
 */

import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function PromoBanner() {
  return (
    <section className="relative py-4 bg-gradient-to-r from-[#1A2B3D] via-[#0D1B2A] to-[#1A2B3D]">
      <div className="container">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 py-4 px-6 rounded-lg bg-gradient-to-r from-[#FF2D2D]/10 via-[#FF2D2D]/5 to-[#FF2D2D]/10 border border-[#FF2D2D]/20">
          {/* The Vibe TV Logo */}
          <div className="flex items-center justify-center">
            <img
              src="/images/thevibe-tv-logo.png"
              alt="The Vibe TV"
              className="h-10 w-auto"
            />
          </div>

          {/* Text */}
          <div className="text-center sm:text-left">
            <p className="text-white font-semibold text-lg">
              The Vibe TV experience for just $4.99
            </p>
            <p className="text-white/70 text-sm">
              Get our most affordable, ad-supported plan.
            </p>
          </div>

          {/* CTA */}
          <Button
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 hover:text-white ml-auto"
            onClick={() => toast.info("Feature coming soon")}
          >
            Learn More
          </Button>
        </div>
      </div>
    </section>
  );
}
