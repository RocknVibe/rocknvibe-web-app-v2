/**
 * Features Grid Component - More Reasons to Join
 * Design: Netflix-Style Glassmorphism
 * - 2x2 grid of glass-effect feature cards
 * - Each card has title, description, and image
 * - Enhanced hover effects with glow and blur
 */

import { cn } from "@/lib/utils";
import { useState } from "react";

interface Feature {
  id: number;
  title: string;
  description: string;
  image: string;
  accent?: string;
}

const features: Feature[] = [
  {
    id: 1,
    title: "Watch on your TV",
    description:
      "Stream on Smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players, and more.",
    image: "/images/live-broadcast.jpg",
  },
  {
    id: 2,
    title: "Download to watch offline",
    description:
      "Save your favorites easily and always have something to watch.",
    image: "/images/record-label.jpg",
  },
  {
    id: 3,
    title: "Watch everywhere",
    description:
      "Stream unlimited music videos and live shows on your phone, tablet, laptop, and TV.",
    image: "/images/music-video.jpg",
  },
  {
    id: 4,
    title: "Exclusive live broadcasts",
    description:
      "Experience live performances from your favorite artists in real-time — free with your membership.",
    image: "/images/artist-feature.jpg",
  },
];

export default function FeaturesGrid() {
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <section className="py-16 bg-[#0D1B2A]" id="live-broadcasts">
      <div className="container">
        {/* Section Header */}
        <h2 className="font-display font-bold text-2xl md:text-3xl text-white mb-8 animate-fade-in">
          More Reasons to Join
        </h2>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {features.map((feature, index) => (
            <div
              key={feature.id}
              className={cn(
                "relative overflow-hidden rounded-2xl glass-effect-strong p-6 md:p-8 min-h-[280px] transition-all duration-500 cursor-pointer group",
                hoveredId === feature.id &&
                  "scale-105 glass-effect-red-strong"
              )}
              onMouseEnter={() => setHoveredId(feature.id)}
              onMouseLeave={() => setHoveredId(null)}
              style={{
                animation: `slide-in-left 0.6s ease-out forwards`,
                animationDelay: `${index * 0.1}s`,
                opacity: 0,
              }}
            >
              {/* Content */}
              <div className="relative z-10 max-w-[60%]">
                <h3 className="font-display font-bold text-xl md:text-2xl text-white mb-3 group-hover:text-glow transition-all duration-300">
                  {feature.title}
                </h3>
                <p className="text-white/70 text-sm md:text-base leading-relaxed group-hover:text-white/90 transition-all duration-300">
                  {feature.description}
                </p>
              </div>

              {/* Image */}
              <div className="absolute right-0 bottom-0 w-[45%] h-[80%] overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-[#1A2B3D] via-[#1A2B3D]/50 to-transparent z-10" />
                <img
                  src={feature.image}
                  alt={feature.title}
                  className={cn(
                    "w-full h-full object-cover transition-transform duration-700",
                    hoveredId === feature.id && "scale-125 brightness-110"
                  )}
                />
              </div>

              {/* Hover Accent Line */}
              <div
                className={cn(
                  "absolute bottom-0 left-0 h-1 bg-gradient-to-r from-[#FF2D2D] to-[#FF2D2D]/50 transition-all duration-500",
                  hoveredId === feature.id ? "w-full" : "w-0"
                )}
              />

              {/* Glow Effect on Hover */}
              <div
                className={cn(
                  "absolute inset-0 bg-gradient-to-br from-[#FF2D2D]/10 to-transparent rounded-2xl transition-all duration-500",
                  hoveredId === feature.id ? "opacity-100" : "opacity-0"
                )}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
