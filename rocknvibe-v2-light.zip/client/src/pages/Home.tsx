/**
 * Home Page - RocknVibe Landing
 * Design: Premium Streaming Elegance
 * 
 * Layout Structure:
 * 1. Header (fixed navigation)
 * 2. Hero (full-screen with email signup)
 * 3. Promo Banner (affordable plan highlight)
 * 4. Trending Carousel (numbered music videos)
 * 5. Features Grid (reasons to join)
 * 6. FAQ Accordion
 * 7. Footer
 */

import { useAuth } from "@/_core/hooks/useAuth";
import FAQ from "@/components/FAQ";
import FeaturesGrid from "@/components/FeaturesGrid";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import PromoBanner from "@/components/PromoBanner";
import TrendingCarousel from "@/components/TrendingCarousel";

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  const { user, loading, error, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen bg-[#0D1B2A]">
      <Header />
      <main>
        <Hero />
        <PromoBanner />
        <TrendingCarousel />
        <FeaturesGrid />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}
