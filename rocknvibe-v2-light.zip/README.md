# RocknVibe V2 - Premium Music Entertainment Platform

A modern, high-performance web application for streaming music videos, live broadcasts, and entertainment content. Built with React, TypeScript, TailwindCSS, and featuring Netflix-style glassmorphism effects.

## ✨ Features

### Frontend
- **Netflix-Style Glassmorphism**: Frosted glass effects with backdrop blur for a premium look
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices
- **Smooth Animations**: Fade-in, slide-in, and scale animations for enhanced UX
- **Brand Colors**: Consistent use of primary red (#FF2D2D) and navy blue (#0D1B2A)
- **Modern UI Components**: Built with Radix UI and TailwindCSS
- **Real-time Feedback**: Toast notifications for user actions

### Backend
- **tRPC API**: Type-safe API communication with automatic validation
- **Express Server**: Lightweight and performant HTTP server
- **Rate Limiting**: Protection against abuse with configurable rate limits
- **Security Headers**: Comprehensive security headers for XSS, clickjacking, and MIME sniffing protection
- **Request Logging**: Detailed logging for debugging and monitoring
- **Error Handling**: Standardized error responses with proper HTTP status codes
- **Authentication**: OAuth integration with session management
- **Database**: MySQL with Drizzle ORM for type-safe queries

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ (v22.13.0 recommended)
- pnpm 10.4.1+
- MySQL 8.0+

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/rocknvibe-web-app.git
   cd rocknvibe-web-app
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Setup environment variables**
   ```bash
   cp .env.example .env.local
   ```

   Update `.env.local` with your configuration:
   ```env
   # Server
   PORT=3000
   NODE_ENV=development

   # Database
   DATABASE_URL=mysql://user:password@localhost:3306/rocknvibe

   # OAuth (if using)
   OAUTH_CLIENT_ID=your_client_id
   OAUTH_CLIENT_SECRET=your_client_secret

   # Frontend
   VITE_API_URL=http://localhost:3000
   ```

4. **Setup database**
   ```bash
   pnpm run db:push
   ```

5. **Start development server**
   ```bash
   pnpm run dev
   ```

   The app will be available at `http://localhost:3000`

## 📦 Available Scripts

```bash
# Development
pnpm run dev          # Start development server with hot reload

# Production
pnpm run build        # Build for production
pnpm run start        # Start production server

# Utilities
pnpm run check        # Type check with TypeScript
pnpm run format       # Format code with Prettier
pnpm run test         # Run tests with Vitest

# Database
pnpm run db:push      # Generate and run migrations
```

## 🏗️ Project Structure

```
rocknvibe-web-app/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/    # Reusable React components
│   │   ├── pages/         # Page components
│   │   ├── lib/           # Utility functions
│   │   ├── contexts/      # React contexts
│   │   ├── hooks/         # Custom React hooks
│   │   └── index.css      # Global styles with glassmorphism effects
│   └── index.html         # HTML entry point
├── server/                 # Express backend
│   ├── _core/
│   │   ├── index.ts       # Main server entry
│   │   ├── trpc.ts        # tRPC configuration
│   │   ├── context.ts     # tRPC context
│   │   ├── middleware.ts  # Express middleware
│   │   ├── utils.ts       # Backend utilities
│   │   └── ...
│   ├── routers.ts         # API routes
│   └── index.ts           # Production server
├── drizzle/               # Database schema and migrations
├── shared/                # Shared types and constants
└── package.json           # Dependencies and scripts
```

## 🎨 Design System

### Colors
- **Primary Red**: `#FF2D2D` (oklch(0.628 0.258 27.33))
- **Navy Blue**: `#0D1B2A` (oklch(0.188 0.033 248.05))
- **Light Navy**: `#1A2A3A` (oklch(0.248 0.033 248.05))
- **Pink Accent**: `oklch(0.78 0.08 10)`

### Typography
- **Display Font**: Montserrat (headings)
- **Body Font**: Open Sans (body text)

### Glass Effects
- **`.glass-effect`**: Base glass effect with 12px blur
- **`.glass-effect-strong`**: Stronger glass effect with 16px blur
- **`.glass-effect-subtle`**: Subtle glass effect with 8px blur
- **`.glass-effect-red`**: Glass effect with red accent border
- **`.glass-effect-red-strong`**: Strong glass effect with red accent

### Animations
- **`animate-fade-in`**: Fade in with slide up
- **`animate-slide-in-left`**: Slide in from left
- **`animate-slide-in-right`**: Slide in from right
- **`animate-scale-in`**: Scale in from center
- **`animate-float`**: Floating animation
- **`animate-glow-pulse`**: Glow pulse animation

## 🔒 Security Features

- **Rate Limiting**: Protects against brute force attacks
  - API: 100 requests/minute
  - Auth: 5 requests/5 minutes
  - Upload: 10 requests/hour

- **Security Headers**:
  - X-Frame-Options: SAMEORIGIN
  - X-Content-Type-Options: nosniff
  - X-XSS-Protection: 1; mode=block
  - Content-Security-Policy
  - Referrer-Policy: strict-origin-when-cross-origin

- **Input Validation**: All inputs validated with Zod
- **CORS**: Configured for specific origins
- **Session Management**: Secure cookie-based sessions

## 📊 Performance Optimizations

- **Code Splitting**: Automatic code splitting with Vite
- **Lazy Loading**: Components and routes loaded on demand
- **Image Optimization**: Optimized images with proper formats
- **Caching**: In-memory caching for frequently accessed data
- **Compression**: Gzip compression for responses
- **Database Indexing**: Optimized database queries with proper indexes

## 🔄 API Documentation

### tRPC Procedures

#### Public Procedures
- `auth.me`: Get current user information
- `auth.logout`: Logout current user

#### Protected Procedures
(Requires authentication)

#### Admin Procedures
(Requires admin role)

### Error Handling

All API errors follow this format:
```json
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "details": {}
}
```

## 🧪 Testing

Run tests with:
```bash
pnpm run test
```

Tests are located in `*.test.ts` files throughout the project.

## 📱 Browser Support

- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- Mobile: iOS Safari 12+, Chrome Android 90+

## 🚢 Deployment

### Production Build
```bash
pnpm run build
```

### Environment Variables for Production
```env
NODE_ENV=production
PORT=3000
DATABASE_URL=mysql://user:password@host:3306/rocknvibe
FRONTEND_URL=https://yourdomain.com
```

### Docker Deployment
```dockerfile
FROM node:22-alpine
WORKDIR /app
COPY . .
RUN pnpm install
RUN pnpm run build
EXPOSE 3000
CMD ["pnpm", "run", "start"]
```

## 📝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Support

For support, email support@rocknvibe.com or open an issue on GitHub.

## 🙏 Acknowledgments

- Netflix for inspiring the glassmorphism design
- Radix UI for accessible components
- TailwindCSS for utility-first CSS
- The open-source community for amazing tools and libraries

---

**Made with ❤️ by the RocknVibe Team**
